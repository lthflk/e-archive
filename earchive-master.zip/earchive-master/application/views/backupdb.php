<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<h2>Cadangkan Database</h2>
<hr>
<div class="row">
	<div class="panel panel-default">
		<div class="panel-heading">Cadangkan Database</div>
  		<div class="panel-body"><a href="<?php echo site_url('admin/backupdatabase');?>" class="btn btn-success" id="backupdb">Unduh</a></div>
	</div>
</div>